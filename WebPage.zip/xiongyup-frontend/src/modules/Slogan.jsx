function Slogan() {
    return (
        <>
            
            <p>Sometimes the best things in life is right in front of you!</p>
            
        </>
    );
}
export default Slogan;