function ContactPage(){
    return (
        <>
            <h2>Contact Page</h2>
            <article>
                <h3>Email:</h3>
                <p>XiongYuPheng@outlook.com</p>
                <h3>Name:</h3>
                <p>YuPheng Xiong</p>
            </article>
        </>
    )
}
export default ContactPage;